import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { User } from 'src/app/interface/user';
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-editprofile',
  templateUrl: './editprofile.component.html',
  styleUrls: ['./editprofile.component.css']
})
export class EditprofileComponent implements OnInit {
  data = {} as User
  editForm: FormGroup = new FormGroup({});

  constructor(private userService: UserService) { }

  ngOnInit(): void {
    let id = sessionStorage.getItem('isUserId')
    console.log("id ", id);

    this.userService.getUserById(id).then(res => {
      this.data = res.data[0]
      console.log("r ", this.data);

      const splitOnSpace = this.data.name.split(' ');
      console.log("s ", splitOnSpace[0]);

      this.editForm = new FormGroup({
        userId: new FormControl(this.data.id, Validators.required),
        firstName: new FormControl(splitOnSpace[0], Validators.required),
        lastName: new FormControl(splitOnSpace[1], Validators.required),
        email: new FormControl(this.data.email, Validators.required),
        // password: new FormControl(this.data.password, Validators.required),
        contact: new FormControl(this.data.contact, Validators.required),
        gender: new FormControl(this.data.gender, Validators.required),
        dateOfBirth: new FormControl(this.data.date_of_birth, Validators.required),
        location: new FormControl(this.data.location, Validators.required),
        pincode: new FormControl(this.data.pincode, Validators.required),
        city: new FormControl(this.data.city, Validators.required),
      });
    })
  }

  submit() {

  }
}
