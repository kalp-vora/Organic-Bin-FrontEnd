import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {

  constructor(private http: HttpClient) { }
  public applicationStatus: any = { 0: "Pending", 1: "Approve", 2: "Rejected" };

  token = sessionStorage.getItem('isToken')

  addAppointment(model: any): Observable<any> {
    let header = new HttpHeaders().set("Authorization", 'Bearer ' + this.token);
    return this.http.post(`${environment.base_URL}customer/appointment/add`, model, { headers: header });
  }

  getAppointmentById(userId: any): Promise<any> {
    let header = new HttpHeaders().set("Authorization", 'Bearer ' + this.token);
    return this.http.get(`${environment.base_URL}customer/appointment/get/${userId}`, { headers: header }).toPromise()
  }

  getAllAdminAppointment(): Promise<any> {
    let header = new HttpHeaders().set("Authorization", 'Bearer ' + this.token);
    return this.http.get(`${environment.base_URL}admin/customer/appointment/get/all`, { headers: header }).toPromise()
  }
}
