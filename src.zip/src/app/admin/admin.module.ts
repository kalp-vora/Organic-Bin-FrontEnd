import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CityComponent } from './city/city.component';
import { StateComponent } from './state/state.component';
import { AddeditcityComponent } from './city/addeditcity/addeditcity.component';
import { AddeditstateComponent } from './state/addeditstate/addeditstate.component';
import { UserappointmentComponent } from './userappointment/userappointment.component';
import { UserComponent } from './user/user.component';
import { HttpClientModule } from '@angular/common/http';
import { ToastModule } from 'primeng/toast';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    DashboardComponent,
    CityComponent,
    StateComponent,
    AddeditcityComponent,
    AddeditstateComponent,
    UserappointmentComponent,
    UserComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    ConfirmDialogModule,
    ToastModule,
    HttpClientModule
  ]
})
export class AdminModule { }
