import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  token = sessionStorage.getItem('isToken')

  getUserById(userId: any): Promise<any> {
    let header = new HttpHeaders().set("Authorization", 'Bearer ' + this.token);
    return this.http.get(`${environment.base_URL}user/${userId}`,{headers:header}).toPromise()
  }

  getAllUser(): Promise<any> {
    let header = new HttpHeaders().set("Authorization", 'Bearer ' + this.token);
    return this.http.get(`${environment.base_URL}admin/user/get/all`, { headers: header }).toPromise()
  }

  isLoggedIn(){
    if(sessionStorage.getItem('isLogin')){
      return true;
    }
    return false;
  }
}
