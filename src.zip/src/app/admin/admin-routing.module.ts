import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddeditcityComponent } from './city/addeditcity/addeditcity.component';
import { CityComponent } from './city/city.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserComponent } from './user/user.component';
import { UserappointmentComponent } from './userappointment/userappointment.component';

const routes: Routes = [
  {
    path: 'admin', component: DashboardComponent, children: [
      { path: 'city', component: CityComponent },
      { path: 'addcity', component: AddeditcityComponent },
      { path: 'userappointment', component: UserappointmentComponent },
      { path: 'user', component: UserComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
