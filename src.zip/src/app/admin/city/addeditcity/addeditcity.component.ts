import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-addeditcity',
  templateUrl: './addeditcity.component.html',
  styleUrls: ['./addeditcity.component.css']
})
export class AddeditcityComponent {
  cityForm: FormGroup = new FormGroup({});

  submit(){
    
  }
}
