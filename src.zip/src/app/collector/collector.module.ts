import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CollectorRoutingModule } from './collector-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CollectorRoutingModule
  ]
})
export class CollectorModule { }
