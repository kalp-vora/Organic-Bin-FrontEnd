import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CityService {

  constructor(private http: HttpClient) { }

  getCityById(stateId: any): Promise<any> {
    return this.http.get(`${environment.base_URL}city/get/${stateId}`).toPromise()
  }

  getCity():Promise<any>{
    return this.http.get(`${environment.base_URL}city/get/all`).toPromise()
  }
}
