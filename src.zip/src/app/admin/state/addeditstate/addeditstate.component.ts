import { Component } from '@angular/core';

@Component({
  selector: 'app-addeditstate',
  templateUrl: './addeditstate.component.html',
  styleUrls: ['./addeditstate.component.css']
})
export class AddeditstateComponent {

}
