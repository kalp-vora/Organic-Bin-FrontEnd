export interface Address {
  id:number;
  userId:number;
  location:string;
  cityId:number;
  
}
