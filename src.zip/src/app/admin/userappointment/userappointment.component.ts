import { Component, OnInit } from '@angular/core';
import { AppointmentService } from 'src/app/service/appointment.service';

@Component({
  selector: 'app-userappointment',
  templateUrl: './userappointment.component.html',
  styleUrls: ['./userappointment.component.css']
})
export class UserappointmentComponent implements OnInit {
  listAppointment: any = {}
  listCollector: any = {}

  constructor(
    public appointmentService: AppointmentService
  ) { }

  ngOnInit(): void {
    this.appointmentService.getAllAdminAppointment().then(res => {
      this.listAppointment = res.data
      // console.log("r ", res.data);
    })
  }
}
