export const environment = {
  production: true,
  base_URL:'https://healthassists.herokuapp.com/'
};
